<?php

use lib\Routing\Router;

require "vendor/autoload.php";

$Router = new Router();
$Router->Request();