<?php

namespace src\Repository;
use lib\DB\Connexion;
use PDO;
use PDOException;
use src\Entity\Question;
use src\Entity\quiz;
use src\Entity\Reponse;

class quizRepository {
    private $pdo;
    private $connexion;

    public function __construct() {
        $connexion =new Connexion();
        $this->connexion = $connexion;
        $pdo = $connexion->getPdo1();
        $this->pdo = $pdo;
    }
    


  

 function findAll(){
    try{
        $stm = $this->connexion->query("SELECT * FROM  quiz where status is not null");
        $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\quiz');
        return $users;
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    }
    // Fonction de création d'un quiz
    function create_quiz(quiz $quiz )  {
        
        try{
            $this->connexion->query("insert into quiz(Creator_id,title,description,duration,created_at) values (?,?,?,?,CURRENT_TIMESTAMP())",[$quiz->getCreatorId(),$quiz->getTitle(), $quiz->getDescription(), $quiz->getDuration()]);
            $id=$this->connexion->getPdo();
            return $id;  
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }          
    }
    // Fonction pou ajouter des questions
    function addQuestion($id,$enonce,$score){
        try{

            $this->connexion->query('insert into question set enonce =?,score=?,quiz_id=?',
                                    [$enonce,$score,$id]);
            $id=$this->connexion->getPdo();
            return $id;     

        }catch(PDOException $e){
            echo $e->getMessage();
        }

    }
// ajouter les choix 
    function addAnswer($answer,$id,$is_correct){
        try{
            $this->connexion->query('insert into answerquiz set enonce =?, id_quest=?,is_correct=?',[ $answer,$id,$is_correct]);


        }catch(PDOException $e){
            echo $e->getMessage();
        }

    }
    public function getAll($id) {
        
        try{
            
            $stm=$this->connexion->query("select * from quiz where Creator_id = ?",[$id]);
            
            $quiz = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\Quiz');
            return $quiz;
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
    
    
    }


    function get_correct($id) {
        try{
        $stmt = $stmt=$this->connexion->query("select * from answerquiz WHERE is_correct = 1 and id_quest=?",[$id]);
        $questions = $stmt->fetchAll(PDO::FETCH_CLASS,'src\Entity\Question');
        return $questions;
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
    }
    // recupere les questions d'un qcm
    function get_question($quiz_id) {
        try{
        $stmt = $stmt=$this->connexion->query("select * from question WHERE quiz_id = ?",[$quiz_id]);
        $questions = $stmt->fetchAll(PDO::FETCH_CLASS,'src\Entity\Question');
        return $questions;
    }
    catch(PDOException $e){
        echo $e->getMessage();
    }
    }
    // fonction pour recupérer quiz par id 
    public function getById($id) {
    
        
        try{
            $stm = $this->connexion->query("select * from quiz where id = ?",[$id]);
            $quiz = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\Quiz');
            return $quiz[0];
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
        
    }
    // recuperer les reponse de chaque question
    function get_question_answers($id_quest) {
        try{
        $sql = "select * from answerquiz WHERE id_quest = ?";
        $stmt = $this->connexion->query($sql,[$id_quest]);
        $answers = $stmt->fetchAll(PDO::FETCH_CLASS,'src\Entity\Reponse');
        return $answers;
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    

 }
 // supprimer les question du quiz
  public function delete_questions($id){
      try{
            $this->connexion->query("delete from  question where  quiz_id=? ",[$id]);
 
        }
      catch(PDOException $e){
          echo $e->getMessage();
        }
    }


 // modifier quiz
    public function updateQuiz(quiz $quiz){      
        try{
            $this->connexion->query("update quiz set title =?,  description=?,duration =?, updated_at=CURRENT_TIMESTAMP() where id =? and Creator_id =? ",
            [$quiz->getTitle(), $quiz->getDescription(), $quiz->getDuration(), $quiz->getId(),$quiz->getCreatorId()]);            
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
    }
 // supprimer le quiz
  public function delete_quiz($id){
     try{
         $this->connexion->query("delete from  quiz where id=? ",[$id]);
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
    }
    // modifier question
    public function modifierQuestion($id,Question $question){

        try{
            $this->connexion->query("update question set enonce =?,  score=?,correct_answer =? where quiz_id =?",
            [$question->getEnonce(), $question->getScore(), $id]);            
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
    }
    // modifier les choix 
    public function modifierChoice($id,$response){
        try{
            $this->connexion->query("update answerquiz set enonce=? where id=?", 
            [$response,$id]);
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }
    }


    public function resultat($id){

        try{
            $sql = 'select * from answerquiz where is_correct =? ';
            $stmt = $this->connexion->query($sql,[$id]);
            $resultat = $stmt->fetchAll(PDO::FETCH_CLASS,'src\Entity\Reponse');
           return $resultat;
        }
        catch(PDOException $e){
            echo $e->getMessage();
        }

    }

    // Suppression des anciennes réponses de l'utilisateur pour la question donnée
    public function deletereponse($user_id,$quiz_id){                 
         $pdo = $this->pdo;
         try { $stm = $pdo->prepare("DELETE FROM answers WHERE user_id = ? AND quiz_id = ?");
         $stm->execute([$user_id, $quiz_id]);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }


    // Fonction de sauvegarde des réponses de l'utilisateur pour un quiz   
    public function save_user_quiz_responses($user_id, $quiz_id, $question_id, $answers) {
        $pdo = $this->pdo;
        try {
            foreach ($answers as $answer) {
                $stm1 = $pdo->prepare("INSERT INTO answers (user_id, quiz_id, question_id, answer_value) VALUES (?,?,?,?)"); 
                $stm1->execute([$user_id, $quiz_id, $question_id, $answer]);
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
    
// fonction pour verifier si les reponse de l'utilisateur sont juste après avoir passer le qcm
public function is_correct(){
    try{
        $this->connexion->query("update answers a, answerquiz q set a.is_correct=true where 
        a.answer_value=q.id and q.is_correct=true ");
    }

    catch(PDOException $e){
        echo $e->getMessage();}

}



public function score1($quiz_id){
    $pdo = $this->pdo;
    try{
        $score=0;
        $stmt=$this->connexion->query("SELECT SUM(q.score) FROM question q, answers a 
        WHERE q.quiz_id = a.quiz_id AND a.is_correct = TRUE  ");

        if($stmt==false){$score =0;}
else{$score = 0+$stmt->fetch(PDO::FETCH_ASSOC)['SUM(q.score)'];
}

        return $score;

    } catch(PDOException $e) {
        $pdo->rollBack();

        echo $e->getMessage();
    }


}

// fonction calcul le score total de l'utilisateur pour chaque qcm
public function score($user_id,$quiz_id){
    $pdo = $this->pdo;
    try{
        $pdo->beginTransaction();

        $stmt=$pdo->prepare("SELECT SUM(q.score) FROM question q 
    INNER JOIN answerquiz aq ON q.id = aq.id_quest
    LEFT JOIN answers a ON aq.id = a.answer_value AND a.user_id = ?
    WHERE q.quiz_id = ? AND (aq.is_correct = TRUE AND a.is_correct = TRUE)
    GROUP BY q.id");
$stmt->execute([$user_id, $quiz_id]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
$score = 0;
foreach ($rows as $row) {    
    $score += $row['SUM(q.score)'];
}
        $this->connexion->query("INSERT INTO quiz_users (user_id, quiz_id, score, date_quiz) VALUES (?, ?, ?, CURRENT_TIMESTAMP()) ",
        [$user_id, $quiz_id, $score]);
        $pdo->commit();
        return $score;
    } catch(PDOException $e) {
        $pdo->rollBack();

        echo $e->getMessage();
    }


}



}