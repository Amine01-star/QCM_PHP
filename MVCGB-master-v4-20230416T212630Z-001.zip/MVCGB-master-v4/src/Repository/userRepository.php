<?php

namespace src\Repository;
use lib\DB\Connexion;
use PDO;
use PDOException;
use src\Entity\Quiz;
use src\Entity\user;

class userRepository {
    private $connexion;

    public function __construct() {
        $connexion =new Connexion();
        $this->connexion = $connexion;
       $pdo = $connexion->getPdo();
    }
    

/*
    public function findAllQuizs(){
        try{
            $stm = $this->connexion->query("SELECT id ,Creator_id ,title,description,duration,created_at,updated_at,status, id_admin FROM quiz ");
            $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\Quiz');
            return $users;
        }catch(PDOException $e){
            echo $e->getMessage();
        }
    }*/




    
    public function findDetails($id) {
        try {
        $stm = $this->connexion->query("SELECT * FROM question WHERE id=?", [$id]);
        $quizs = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\question');
            if (isset($quizs[0])) {          
                return $quizs[0];
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
    }



    public function findAllQuizs($nullable){
        try{
            if($nullable ==1){
            $stm = $this->connexion->query("SELECT q.id, q.Creator_id, q.title, q.description, q.duration, q.created_at, q.updated_at, q.status, q.id_admin, a.nom AS admin_name 
            FROM quiz q 
            
            LEFT JOIN user a ON q.id_admin = a.id AND q.id_admin <> 0; ");
            }elseif($nullable==2){


                $stm = $this->connexion->query("SELECT q.id, q.Creator_id, q.title, q.description, q.duration, q.created_at, q.updated_at, q.status, q.id_admin, u.nom AS admin_name
                FROM quiz q
                JOIN user u ON q.id_admin = u.id WHERE q.status is null");
            }elseif($nullable==3){
                
                $stm = $this->connexion->query("SELECT q.id, q.Creator_id, q.title, q.description, q.duration, q.created_at, q.updated_at, q.status, q.id_admin, u.nom AS admin_name
                FROM quiz q
                JOIN user u ON q.id_admin = u.id WHERE q.status is not null");

            }
            $quizs = $stm->fetchAll(PDO::FETCH_ASSOC);
            
            $quizObjects = [];
            foreach ($quizs as $quiz) {
                $quizObject = new Quiz();
                $quizObject->setId($quiz['id']);
                $quizObject->setCreatorId( $quiz['Creator_id']);
                $quizObject->setTitle ($quiz['title']);
                $quizObject->setDescription($quiz['description']);
                $quizObject->setDuration( $quiz['duration']);
                $quizObject->setCreatedAt( $quiz['created_at']);
                $quizObject->setUpdatedAt($quiz['updated_at']);
                $quizObject->setStatus($quiz['status']);
                $quizObject->setIdAdmin($quiz['id_admin']);
                $quizObject->setAdminName($quiz['admin_name']);
                $quizObjects[] = $quizObject;
            }
            
            return $quizObjects;
        }catch(PDOException $e){
            echo $e->getMessage();
        }
    }
    
    
    public function findAll($id_rolen, $role_id){
        try{
            $stm = $this->connexion->query("SELECT * FROM user WHERE role_id < " . intval($id_rolen) . " AND role_id = " . intval($role_id));
            $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\user');
            return $users;
        }catch(PDOException $e){
            echo $e->getMessage();
        }
    }

    public function ResetPassword(){
        try{
                $stm = $this->connexion->query("SELECT * FROM user WHERE id = ? AND reset_token IS NOT NULL AND reset_token = ? AND reset_at > DATE_SUB(NOW(), INTERVAL 30 MINUTE)",[$_GET['id'], $_GET['token']]);
                $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\user');
                return $users;
            }catch(PDOException $e){
                echo $e->getMessage();
            }
    }


    public function updtePassword($password){
        try{
            $this->connexion->query('UPDATE user SET password = ?, reset_at = NULL, reset_token = NULL',[$password]);
            }catch(PDOException $e){
                echo $e->getMessage();
            }

    }



    
 

    public function findUser($id, $roleId = 0) {
        try {
            if ($roleId == 0) {
                // if roleId is not provided, search for super admin
                $stm = $this->connexion->query("SELECT * FROM user WHERE id=?", [$id]);
            } else {
                // if roleId is provided, search for user with id and not with roleId
                $stm = $this->connexion->query("SELECT * FROM user WHERE id=? AND role_id<" . intval($roleId), [$id]);
            }
            $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\user');
            if (isset($users[0])) {          
                return $users[0];
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
    }


    public function findQuiz($id) {
        try {
        $stm = $this->connexion->query("SELECT * FROM quiz WHERE id=?", [$id]);
        $quizs = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\quiz');
            if (isset($quizs[0])) {          
                return $quizs[0];
            }
        } catch(PDOException $e) {
            echo $e->getMessage();
        }
    }

    
    public function connexion(){
        try {
                if(isset($_POST['email']) && !empty($_POST['email'])) {
                    $stm = $this->connexion->query("select * from user where email =? and confirmed_at is not null",[$_POST['email']]);
                    $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\user');
                    return $users;
                }
            }catch(PDOException $e) {
                echo $e->getMessage();
            }
    }

    public function findUserByMail(){
        try{
            $stm= $this->connexion->query('select id from user where  email =?',[$_POST['email']]);
            $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\user');
            return $users;
            } catch(PDOException $e){
                echo $e->getMessage();
            }
    }

    public function create($password,$token,$id){
        try{
                $this->connexion->query('insert into user set nom =?,prenom =?, email=?,password =?,confirmation_token=?,role_id=?',[$_POST['nom'], $_POST['prenom'], $_POST['email'], $password, $token,$id]);
                $user_id=$this->connexion->getPdo();
                return $user_id;

            }catch(PDOException $e){
                echo $e->getMessage();
            }
    }

    public function tokenReset(){
        try{
            $stm = $this->connexion->query('SELECT * FROM user WHERE email = ? AND confirmed_at IS NOT NULL',[$_POST['email']]);
            $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\user');
            return $users;
        }catch(PDOException $e){
            echo $e->getMessage();
        }
    }
        
    public function updateReset($reset_token, $users){
        try{
            $this->connexion->query('UPDATE user SET reset_token = ?, reset_at = NOW() WHERE id = ?',[$reset_token, $users[0]->getId()]);
        }catch(PDOException $e){
            echo $e->getMessage();
        }
    }

    public function editPass($password,$user_id){
        try{
            $this->connexion->query('UPDATE user SET password = ? WHERE id = ?',[$password,$user_id]);
            }catch(PDOException $e){
            echo $e->getMessage();
            }
    }

    public function  updateComfirmation($user_id) {
        try{
            $stm= $this->connexion->query('update user set confirmation_token=NULL,confirmed_at=NOW() where id =? ',[$user_id]);
            }catch(PDOException $e){
                echo $e->getMessage();
            }
    }
        
    public function  comfirmation($user_id) {
        try{
            $stm= $this->connexion->query('select * from user where id=?',[$user_id]);
            $user = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\user');
            return $user;
        
        }catch(PDOException $e){
            echo $e->getMessage();
        } 
    }

public function validateQuiz($id_admin,$id){

            // $pdo = $this->pdo;
            try{
                $this->connexion->query("UPDATE quiz SET status = NOW(), id_admin=? WHERE id = ?",[$id_admin,$id]);
                    
                } catch(PDOException $e){
                    echo $e->getMessage();
                    return false;
                }



}
    public  function deleteQuiz($id){
        // $pdo = $this->pdo;
        try{
            $this->connexion->query("delete from quiz where id=?",[$id]);
            return true;
                
            } catch(PDOException $e){
                echo $e->getMessage();
                return false;
            }
    }
    public  function delete($id){
        // $pdo = $this->pdo;
        try{
            $this->connexion->query("delete from user where id=?",[$id]);
            return true;
                
            } catch(PDOException $e){
                echo $e->getMessage();
                return false;
            }
    }

    public function updateSuper()
    {
        try{
            $this->connexion->query("UPDATE user SET nom=?, prenom=?, email=? WHERE id=?",[$_POST['nom'], $_POST['prenom'], $_POST['email'], $_SESSION['auth']->getId()]);
            $stm = $this->connexion->query("SELECT * FROM user WHERE id=?",[$_SESSION['auth']->getId()]);
            $users = $stm->fetchAll(PDO::FETCH_CLASS, 'src\Entity\user');
            return $users[0];
        } catch(PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }

    public function updateUser($id){
        try{
            $st = $this->connexion->query("UPDATE user SET nom=?, prenom=?, email=?, role_id=? WHERE id=?",[$_POST['nom'],$_POST['prenom'], $_POST['email'],$_POST['role_id'],$id]);
            $stm = $this->connexion->query("SELECT * FROM user WHERE id=?",[$id]);
            $users = $stm->fetchAll(PDO::FETCH_CLASS,'src\Entity\user');
            return $users[0];
        }catch(PDOException $e){
                echo $e->getMessage();
                return false;
        }

    }

}