
<?php

session_start();
unset($_SESSION['auth']);
$_SESSION['flash']['success']="vous etes maintenat deconnecter";

header('Location: http://localhost/MVCGB-master-v4/?action=connexion');


/*<?php

namespace src\View\Index;

use src\View\functions;
use src\View\Session;

//session_start();
//$session = new Session();

Session::getInstance();

//unset($_SESSION['auth']);
Session::getInstance()->setFlash('success',"vous etes maintenat deconnecter");

//$_SESSION['flash']['success']="vous etes maintenat deconnecter";
functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');

//header('Location: http://localhost/MVCGB-master-v4/?action=connexion');
*/


