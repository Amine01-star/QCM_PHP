</main><!-- /.container -->
<?php use  src\View\functions;?>


<div >
  <!-- Footer -->
  <footer class="text-center text-white" style="background-color:#000000;">
    <!-- Grid container -->
    <div class="container p-4 pb-0">
      <!-- Section: CTA -->

        <table style="margin: auto;" >
            <tr  ><td>Register </td> <td ></td>
            <td >Navigation</td>
            <tr><td>
            <a href="http://localhost/MVCGB-master-v4/?action=inscription" class="btn btn-outline-light btn-rounded" role="button">Sign up!</a>

        
        </td>  <td></td><td> 
            
          
        <?php
                $functions =new functions();
                echo $functions-> nav_menu('text-light');

        ?>
          



        </td></tr>
          <tr style="color:white">  <td></td><td style="font-family:cursive;">Enjoy and be happy now, with us</td><td></td></tr>
 
        </table>
        
      <!-- Section: CTA -->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-1" style="background-color: rgba(0, 0, 0, 0);">
      © 2020 Copyright:
      <a class="text-white">MDBootstrap.com</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->

  </div>


</body>
</html>