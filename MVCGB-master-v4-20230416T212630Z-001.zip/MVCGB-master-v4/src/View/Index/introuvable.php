<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Accès interdit</title>
    <style>
      body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
      }
      
      #container {
        margin: 0 auto;
        width: 80%;
        text-align: center;
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
      }
      
      h1 {
        font-size: 36px;
        color: #ff0000;
        margin-bottom: 20px;
      }
    </style>
  </head>
  <body>
    <div id="container">
      <h1>Accès interdit</h1>
      <p>Vous n'avez pas le droit d'accéder à cette page.</p>
    </div>
  </body>
</html>
