<nav class="main-menu">
    <ul>
      <li>
        <a href="?action=dashboard">
          <i class="fa fa-user fa-2x"></i>
          <span class="nav-text">
            Admins page
          </span>
        </a>

      </li>
      <li class="has-subnav">
        <a href="?action=users">
        <i class="fa fa-file-earmark-person fa-2x">
        <svg xmlns="http://www.w3.org/2000/svg" width="22PX" height="22PX" fill="currentColor" class="bi bi-person-square" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
  <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1v-1c0-1-1-4-6-4s-6 3-6 4v1a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12z"/>
</svg>
        </i>
          <span class="nav-text">
          Users Page
          </span>
        </a>

      </li>
      <li class="has-subnav">
        <a href="?action=edit_users">
          <i class="fa  fa-2x">
          <svg xmlns="http://www.w3.org/2000/svg" width="25px" height="25px" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
</svg>

          </i>
          <span class="nav-text">
          Modifier un utilisateur
          </span>
        </a>



      </li>
      <li class="has-subnav">
        <a href="http://localhost/MVCGB-master-v4/?action=create_admin">
          <i class="fa fa-person-fill-add fa-2x">
          <svg xmlns="http://www.w3.org/2000/svg" width="25px" height="25px" fill="currentColor" class="bi bi-person-fill-add" viewBox="0 0 16 16">
  <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"/>
  <path d="M2 13c0 1 1 1 1 1h5.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.544-3.393C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4Z"/>
</svg>
          </i>
          <span class="nav-text">
		  Ajouter un  admin
          </span>
        </a>

      </li>
      <li>
        <a href="http://localhost/MVCGB-master-v4/?action=about">
          <i class="fa fa-film fa-2x"></i>
          <span class="nav-text">
		  Mon profil
          </span>
        </a>
      </li>
      <li>
        <a href="http://localhost/MVCGB-master-v4/?action=editSPass">
          <i class="fa fa-book fa-2x"></i>
          <span class="nav-text">
		  Changet password
          </span>
        </a>
      </li>
      <li>
        <a href="?action=users_dash">
          <i class="fa fa-list-task fa-2x">
          <svg xmlns="http://www.w3.org/2000/svg" width="25px" height="25px" fill="currentColor" class="bi bi-list-task" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M2 2.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5V3a.5.5 0 0 0-.5-.5H2zM3 3H2v1h1V3z"/>
  <path d="M5 3.5a.5.5 0 0 1 .5-.5h9a.5.5 0 0 1 0 1h-9a.5.5 0 0 1-.5-.5zM5.5 7a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm0 4a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9z"/>
  <path fill-rule="evenodd" d="M1.5 7a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5V7zM2 7h1v1H2V7zm0 3.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5H2zm1 .5H2v1h1v-1z"/>
</svg>
          </i>
          <span class="nav-text">
		  Liste des QCM
          </span>
        </a>
      </li>
      <li class="has-subnav">
        <a href="?action=user_quiz">
          <i class="fa fa-list fa-2x"></i>
          <span class="nav-text">
		  Afficher mes qcm
          </span>
        </a>

      </li>

    </ul>


  </nav>
  