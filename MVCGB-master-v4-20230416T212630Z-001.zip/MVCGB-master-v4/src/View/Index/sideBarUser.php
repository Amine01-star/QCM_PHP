<nav class="main-menu-user" >
    <ul>
      <li>
        <a href="?action=/">
          <i class="fa fa-home fa-2x"></i>
          <span class="nav-text">
            Acceuil
          </span>
        </a>

      </li>
      <li class="has-subnav">
        <a href="?action=create_quiz">
          <i class="fa fa-plus fa-2x"></i>
          <span class="nav-text">
		  Ajouter un QCM
          </span>
        </a>

      </li>
      <li class="has-subnav">
        <a href="?action=afficher_tout_quiz">
          <i class="fa fa-check fa-2x"></i>
          <span class="nav-text">
		  Passer un QCM
          </span>
        </a>

      </li>
      <li class="has-subnav">
        <a href="?action=user_quiz">
          <i class="fa fa-list fa-2x"></i>
          <span class="nav-text">
		  Afficher mes qcm
          </span>
        </a>

      </li>
      

    </ul>


  </nav>
 