
<?php

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBar.php';

require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php';


use src\Repository\userRepository;

?>


<?php 

if(isset($user)){
$nom=$user->getNom();
$prenom=$user->getPrenom();
$email=$user->getEmail();
}
 ?>

<?php
use src\Controller\UserController;
use src\Entity\user;

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';


        ?>
<section  class="h-100 "style="background-color: #ffff;">
        <div class="container py-5 h-100">
          <div >
            <div class="col">
              <div class="card card-registration my-4">
                <div class="row g-0">






                  <div class="col-md-6 mx-auto">
                    <div class="card-body p-md-5 text-black">
                      <h3 class="mb-5 text-uppercase">Student registration form</h3>



                   <form  action ="" method="POST">

<div>







</div>




                      <div class="row">
                        <div class="col-md-6 mb-4">
                          <div class="form-outline">
                            <input type="text" id="form3Example1m" class="form-control form-control-lg" value="<?php  if(isset($nom)){echo $nom;}  ?>" name="nom" required   />
                            <label class="form-label" for="form3Example1m">Nom</label>

                          </div>
                        </div>

                        <div class="col-md-6 mb-4">
                          <div class="form-outline">
                            <input type="text" id="form3Example1n" class="form-control form-control-lg" name="prenom" value="<?php    if(isset($prenom)){echo $prenom;} ?> "required />
                            <label class="form-label" for="form3Example1n">Prenom</label>
                          </div>
                        </div>
                      </div>


                      
                      <div class="form-outline mb-4">
                        <input type="email" id="form3Example97" class="form-control form-control-lg" name="email" value="<?php   if(isset($email)){echo $email;} ?> " required />
                        <label class="form-label" for="form3Example97">Email </label>
                      </div>
   
                      
                        <div class="d-flex justify-content-center pt-3">
  <button type="submit" class="btn btn-warning btn-lg ms-2" name="modifier">Submit form</button>
</div>
                   </form>


                        </div>

                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
</section>
<div class="mb-4"></div>

 <?php  require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php'; ?>





<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php';
?>
