<?php

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';


require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php';?>
    <style>
      body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}
        .b {
            margin-top: 10px;
		    background: #CC8C18;
            color: white;
            padding: 10px 20px;
            outline: none;
            border: none;
		
	}
    .p-3{
            margin-left: 30px;
            width: 820px;
            
		
        }
        
    .passer{
        color: #FFFFFF;
        background: #343A40;
        padding: 6px;
        Font: 20px -apple-system;
        margin-right:10px ;
        border-radius: 12px;

    } 
    a {
 text-decoration: none;
 color: white; /*par exemple*/
}   
        
    </style>

<section class="h-220 bg-f2f2f2">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
          <div class="col-xl-6">
                    <div class="card-body p-md-5 text-black">
                        <center>
                      <h3 class="mb-5 text-uppercase">Liste de mes QCM</h3></center>
                      </div>
    <form method="post" action="?action=user_quiz">
        
    <?php 
    foreach($quiz as $quizs){
			echo '
            
                <div class="p-3 border bg-light  ">';
            //echo'<input type="hidden" name="id" value="'.$quizs->getId().'>';
			      echo '<h2>'.$quizs->getTitle().'</h2>';
            echo'<label> Description: '.$quizs->getdescription().'</label><br>';
            echo'<label> Durée: '.$quizs->getDuration().'</label>';
            echo '<input type="hidden" name="quiz_id" value="'.$quizs->getId().'" />';
            
            
			echo '<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;<button class="passer " type="submit"><a href="?action=supprimer_quiz&quiz_id='.$quizs->getId().'">Supprimer ce quiz</a></button>';
			echo '</div>&nbsp;';}
		?>
        
    </form>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
    
<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBarUser.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php';
?>