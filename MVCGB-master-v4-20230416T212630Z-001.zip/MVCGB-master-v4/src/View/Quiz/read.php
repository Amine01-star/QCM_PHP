<?php 
public function PasserQuiz(){

//  Session::getInstance();
Functions::logged_only();
if(isset($_SESSION['auth'])){
  $idCreator=$_SESSION['auth']->getId();
    $quiz_id = $_GET['quiz_id'];     
    $questions=$this->rep->get_question($quiz_id);
    $quizs=$this->rep->getById($quiz_id);
    foreach($questions as $question){
    $answers=$this->rep->get_question_answers($question->getId());
  }



  $view =  new View();
$view->render('Quiz/PasserQuiz',['questions'=>$questions, 'quizs'=>$quizs,'answers'=>$answers]);  

}else{
$quiz_id = $_GET['quiz_id'];     
$questions=$this->rep->get_question($quiz_id);
$quizs=$this->rep->getById($quiz_id);
foreach($questions as $question){
$answers=$this->rep->get_question_answers($question->getId());
}



$view =  new View();
$view->render('Quiz/PasserQuiz',['questions'=>$questions, 'quizs'=>$quizs,'answers'=>$answers]);  
}



if ($_SERVER['REQUEST_METHOD'] == 'POST' &&isset($_POST['quiz_id'])) {
  $answers = $_POST['answer'];
  $question_id=$_POST['question_id'];
  $quiz_id=$_POST['quiz_id'];
  
  
  foreach ($answers as $answer_value) {
    
    $this->rep->save_user_quiz_responses($idCreator,$_POST['quiz_id'],$question_id, $answer_value);
           
  }
  $this->rep->is_correct($idCreator);
  $score=$this->rep->score($idCreator,$quiz_id);
  $view =  new View();
  $view->render('Quiz/Resultat');

}}

