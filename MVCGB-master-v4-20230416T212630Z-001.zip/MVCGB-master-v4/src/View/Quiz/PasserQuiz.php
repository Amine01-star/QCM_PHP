<?php

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';


require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php'; ?>

<section class="vh-250" >
  <div class="container py-5 h-110">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
            <div class="col-xl-6 h-110">
              <div class="card-body p-md-5 text-black">
                <h3 class="mb-5 text-uppercase">Repondre au QCM</h3>
              </div>
              <center><div id="countdown"></div></center>
              <br>
              <form method="POST" action="?action=resultat" id="quiz-form"> 
                
              <?php
  echo '<input type="hidden" name="quiz_id" value="'.$quizs->getId().'" />';
  $question_number=0;
  foreach ($questions as $question) {
    echo '<div class="quiz mb-4 col-xl-6 col-xl-10 ">';
    echo '<p >' . $question->getEnonce() . "</p>";
    echo '<input type="hidden" name="question_'.$question_number.'" value="'.$question->getId().'"/>';
    echo "<ul>"; 
    $answernum=1;
    $question_answers = $answers[$question->getId()]; // Retrieve the answers for the current question
    foreach($question_answers as $answer){ // Iterate over the answers for the current question only
      $a = $answer->getEnonce();
      if (!empty($a)) {
        echo "<li><input type='checkbox' name='answer".$question_number.$answernum ."' value='". $answer->getId()."'>" .$a. "</li>";

      }

      $answernum++;
    }  
    echo "</ul>";
    echo '</div>';
    $question_number++;
  }
?>

  <button type="submit">Soumettre les réponses</button>
  <br>
</form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<style>
  body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}
  .b {
    margin-top: 10px;
    background: #CC8C18;
    color: white;
    padding: 10px 20px;
    outline: none;
    border: none;

  }

  .quiz {
    border: 1px solid #ccc;
    margin-bottom: 10px;
    padding: 10px;
    width: 500px;
    margin-left: 10px;
    margin: 0 auto;
  }

  .countdown {
    text-align: center;
    font-size: 90px;
    margin-top: 0px;
    margin-left: 200px;
  }
</style>
<script>
  // Définir le temps initial en secondes
  var countDownTime = <?php echo $quizs->getDuration(); ?>*60;

  // Fonction pour mettre à jour le compte à rebours toutes les secondes
  var countDownInterval = setInterval(function() {
    // Décrémenter le temps restant
    countDownTime--;

    // Calculer les minutes et les secondes restantes
    var minutes = Math.floor(countDownTime / 60);
    var seconds = countDownTime % 60;

    // Afficher le temps restant
    var countdownElement = document.getElementById('countdown');
    countdownElement.innerHTML = "       Temps restant : " + minutes + " min " + seconds + " sec";

    // Si le temps restant est écoulé, arrêter le compte à rebours et soumettre le formulaire
    if (countDownTime <= 0) {
      clearInterval(countDownInterval);
      document.getElementById('quiz-form').submit();
    }
  }, 1000);
</script>

<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBarUser.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php';
?>