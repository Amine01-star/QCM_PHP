<?php

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';


require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php';?>


  <style>/* Set default font family and font size */
/* Body styles */



body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}

/* Heading styles */
h1 {
  text-align: center;
  margin-top: 20px;
  margin-bottom: 20px;
}

/* Container for questions */
#questions {
  padding: 20px;
}

/* Question styles */
.question {
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
  background-color: #fff;
}

/* Input styles */
input[type="text"] {
  display: block;
  width: 100%;
  margin-bottom: 10px;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 3px;
  box-sizing: border-box;
}


input[type="number"] {
  display: block;
  width: 15%;
  margin-bottom: 10px;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 3px;
  box-sizing: border-box;
}


input[type="checkbox"] {
  margin-right: 5px;
}

/* Button styles */
input[type="button"],button {
  display: inline-block;
  margin-right: 10px;
  margin-bottom: 10px;
  padding: 10px 20px;
  font-size: 16px;
  font-weight: bold;
  color: #fff;
  border: none;
  border-radius: 3px;
  background-color: #CC8C18;
  cursor: pointer;
}

button:hover {
  background-color: #555;
}

/* Answer styles */
.answers {
  margin-top: 10px;
}

/* Delete button styles */
.delete-question {
  float: right;
}

</style>
    <title>Question Creator</title>
    <script>
              questionCount=0;

      function addQuestion() {

              var questionDiv = document.createElement("div");
              questionDiv.classList.add("question");

              
              var questionInput = document.createElement("input");
              questionInput.type = "text";
              questionInput.name = "question";
              questionInput.placeholder = "Type your question here";
              questionInput.name = "question" + questionCount;

              questionDiv.appendChild(questionInput);



/////////////////////this should be in a function that is incremented whe i click click me///////////////////////////
              
              var scoreInput = document.createElement("input");
              scoreInput.type = "number";
              scoreInput.name = "score";
              scoreInput.placeholder = "Score";
              scoreInput.name = "score" + questionCount;


///////////////////////////////////////////////////////

                 questionDiv.appendChild(scoreInput);




        
        var answerDiv = document.createElement("div");
        answerDiv.classList.add("answers");
        questionDiv.appendChild(answerDiv);
       
        var addAnswerButton = document.createElement("input");
        addAnswerButton.type = "button";
        addAnswerButton.value = "Add Answer";

        var answerCount = 0;

                                addAnswerButton.onclick = function() {
                                  
                                  var answerInput = document.createElement("input");
                                  answerInput.type = "text";
                                  answerInput.name = "answer";
                                  answerCount++;
                                  answerInput.name = "answer"+ (questionCount-1)+answerCount;
                                  answerInput.id= "answer"+ (questionCount-1)+answerCount;


                                    // Add the input element to the page
                                  document.body.appendChild(answerInput);

                                  //////////////////////////////*****************/////////////////////////// */
                                  

                                  /////////////////////////////////////////////////////////////
                                  answerInput.placeholder = "Type your answer here";
                                  ////////////////////////////////////////////////////
                                  
                                  var answerCheckbox = document.createElement("input");
                                  answerCheckbox.type = "checkbox";
                                  answerCheckbox.name = "correct-answer"+ (questionCount-1)+answerCount;
                                  answerCheckbox.id = "correct-answer"+ (questionCount-1)+answerCount;

                                  
                                  var answerLabel = document.createElement("label");
                                  answerLabel.innerHTML = "Correct answer?";
                                  answerLabel.appendChild(answerCheckbox);


                                  answerCheckbox.addEventListener('change', function() {
    if (this.checked) {
        var answerInputId = this.id.replace("correct-answer", "answer"); // get corresponding answer input ID
        var answerInputValue = document.getElementById(answerInputId).value; // get corresponding answer input value
        this.value = answerInputValue; // set the value of the checkbox to the answer input value
    } else {
        this.value = ""; // clear the value of the checkbox if it is unchecked
    }
});

                                  
                                  //////////////////////////delete answer
                                  var deleteAnswerButton = document.createElement("button");
                                  deleteAnswerButton.innerHTML = "Delete Answer";
                                              deleteAnswerButton.onclick = function() {
                                                answerInput.remove();
                                                answerCheckbox.remove();
                                                answerLabel.remove();
                                                deleteAnswerButton.remove();
                                              };
                                  
                                  answerDiv.appendChild(answerInput);
                                  answerDiv.appendChild(answerLabel);
                                  answerDiv.appendChild(deleteAnswerButton);
                                };
        questionDiv.appendChild(addAnswerButton);
        
        //////////////////delete//////////////////////////
        var deleteQuestionButton = document.createElement("button");
        deleteQuestionButton.innerHTML = "Delete Question";
                  deleteQuestionButton.onclick = function() {
                    questionDiv.remove();
                  };
        questionDiv.appendChild(deleteQuestionButton);
        
        document.getElementById("questions").appendChild(questionDiv);

        questionCount++;



      }

    </script>

  </head>
  <body>
    <h1>Création d'un QCM</h1>

    <section class="h-220 bg-f2f2f2">
	<div class="container px-5 h-170">
          <div class="row d-flex justify-content-center align-items-center h-300">
            <div class="col">
              <div class="card card-registration mx-2">
                <div class="row g-0">
	<div class="col-xl-9">
                    <div class="card-body p-md-5 text-black">
<form action ="" method="POST">
<div class="col-md-9 mb-5">
                          <div class="form-outline">
	<input type="hidden" name="user_id" value="<?php echo $_SESSION['auth']->getId() ?>">
						  </div></div>
	<div class="col-md-9 mb-5">
                          <div class="form-outline">
		<label for="quiz_name">Nom du quiz:</label>
		<input type="text" id="quiz_name" name="quiz_name" required><br>
						  </div>
	</div>
	<div class="col-md-9 mb-5">
                          <div class="form-outline">
		<label for="quiz_description">Description:</label>
		<textarea id="quiz_description" name="quiz_description" required></textarea><br>
						  </div>
	</div>
	<div class="col-md-9 mb-5">
                          <div class="form-outline">
		<label for="quiz_duration">Durée (en minutes):</label>
		<input type="number" id="quiz_duration" name="quiz_duration" min="1" max="120" required><br>
						  </div>
	</div>
	
    <div id="questions">
    </div>



	<input type="button"   value="Ajouter une question" onclick="addQuestion()">

	<button type="submit">Créer le quiz</button>

	</form>
  </div></div></div></div></div></div></div>
	</section>
  <?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBarUser.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php';
?>
