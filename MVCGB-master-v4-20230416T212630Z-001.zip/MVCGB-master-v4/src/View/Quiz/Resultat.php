<?php
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php'; ?>


<?php 

    echo <<<HTML

<div class="rep">
    <br>
    <center>
<h1> Merci d'avoir repondre à ce quiz</h1></center>
<p class="A"> votre score est:  <label class="score">$score</label>

</div>

HTML;


/*
if(isset($_SESSION['auth'])){}else{
    echo <<<HTML

    <div class="rep">
        <br>
        <center>
    <h1> Merci d'avoir repondre à ce quiz</h1></center>
    <p class="A"> votre score est:  <label class="score">$score1</label>
    
    </div>
    
HTML;

}*/

?>
<style>
    .rep{
        margin-left: 20%;
        margin-top: 30px;
        border-bottom: 5px;
        background-color: white;
        width: 60%;

        ;
    }
    .A{
        margin-left: 15px;
        font-size: 20px;
        color: black;

    }
    .score{
        font-size: 17px;

    }
    body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}
</style>
<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBarUser.php';
?>