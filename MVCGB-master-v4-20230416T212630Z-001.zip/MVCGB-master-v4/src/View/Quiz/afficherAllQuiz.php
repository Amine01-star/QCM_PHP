<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';?>

<style>
        .b {
            margin-top: 10px;
		    background: #CC8C18;
            color: white;
            padding: 10px 20px;
            outline: none;
            border: none;
		
	}
  .p-3{
            margin-left: 30px;
            width: 820px;
            
		
        }
    .passer{
        color: #FFFFFF;
        background: #343A40;
        padding: 8px;
        Font: 20px -apple-system;
        margin-left:630px ;
        border-radius: 12px;

    } 
    a {
 text-decoration: none;
 color: white; /*par exemple*/
} 
body {
  margin: 0;
  padding: 0;
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}  
        
    </style>

<section>
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
          <div class="col-xl-6">
                    <div class="card-body p-md-5 text-black">
                      <h3 class="mb-5 text-uppercase">Liste des QCM</h3>
                      </div>
    <form method="post" action="?action=afficher_tout_quiz">
    <?php 
    foreach($quiz as $quizs){
			echo '<div class="p-3 border bg-light py-5 h-100 ">';
            //echo'<input type="hidden" name="id" value="'.$quizs->getId().'>';
			echo '<h2>'.$quizs->getTitle().'</h2>';
            echo'<label> Description: '.$quizs->getdescription().'</label><br>';
            echo'<label> Durée: '.$quizs->getDuration().'</label>';
            echo '<input type="hidden" name="quiz_id" value="'.$quizs->getId().'" />';
            
            
			echo '<br><button class="passer " type="submit"><a href="?action=passer_quiz&quiz_id='.$quizs->getId().'">Passer ce quiz</a></button>';
			echo '</div>&nbsp;';}
		?>
        
    </form>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  </section>
  <?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBarUser.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php';?>

