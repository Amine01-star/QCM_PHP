<?php

namespace  src\View;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use src\Entity\user;
use src\Repository\userRepository;

class functions{


    static function redirect($page){
        header("Location:$page");


    }

    

static function pageName(){
    if ($_SERVER['REQUEST_URI'] === '/MVCGB-master-v4/?action=dashboard') {
        return <<<HTML
        <h2 class="mb-4">Admins Page</h2>
HTML;
    }elseif($_SERVER['REQUEST_URI'] === "/MVCGB-master-v4/?action=users"){
        return <<<HTML
        <h2 class="mb-4" >Users Page</h2>
HTML;
    }elseif($_SERVER['REQUEST_URI'] === "/MVCGB-master-v4/?action=users_dash"){
        return <<<HTML
        <h2 class="mb-4" >Quizes Page</h2>
HTML;
    }
}


function nav_item(string $lien , string $title, string $class=''): string
{
    
    $classe = 'nav-item';
    if($_SERVER['REQUEST_URI'] === $lien){
        $classe .= ' active';
    }

  
        return <<<HTML
        <li class="$classe">
        <a class="$class" href="$lien" >$title</a>
        </li>
    HTML;
    
    
}
function nav_menu(string $class = ''): string
{

   return $this->nav_item('/MVCGB-master-v4/?action=/','Acceuil',$class).$this->nav_item('/MVCGB-master-v4/?action=afficher_tout_quiz','Liste QCM',$class).$this->nav_item('/MVCGB-master-v4/?action=create_quiz','Créer QCM',$class).$this->nav_item('/MVCGB-master-v4/?action=dashboard','Admin',$class);


 
}



static function countCorrectAnswers(){
  $allanswers=[];

  foreach ($_POST as $key => $value) {
    if (strpos($key, 'correct-answer') === 0) {

      array_push( $allanswers,$_POST[$key] );



    }
  } return $allanswers;
 }


static function countAnswers(){
    $countquest = 0;
    foreach ($_POST as $key => $value) {
      if (strpos($key, 'question') === 0) {
        $countquest++;
      }
    }
    $allanswers=[];
for($i=0;$i<$countquest;$i++){
  $answers=[];

  $count = 0;

  foreach ($_POST as $key => $value) {
    if (strpos($key, 'answer'.$i) === 0) {
      $count++;
    }
  } 
 for($j=1;$j<=$count;$j++){

       array_push( $answers, $_POST['answer'.$i.$j]);
 }

 array_push( $allanswers,$answers);
}


return $allanswers;
   }
///////////////////////quiz=>createQuiz()=>question//////////////////////////////////////

static function countQuestions(){
    $questions = [];

    $count = 0;
    foreach ($_POST as $key => $value) {
      if (strpos($key, 'question') === 0) {
        $count++;
      }
    } 
    for ($i = 0; $i < $count+1; $i++) {
        $question_key = 'question' . $i;
        if (isset($_POST[$question_key])) {
            array_push($questions, $_POST[$question_key]);
        }
    }

    return  $questions;
   }


   //////////////////////////////////
   static function countScore(){
    $scores = [];

    $count = 0;
    foreach ($_POST as $key => $value) {
      if (strpos($key, 'score') === 0) {
        $count++;
      }
    } 
    for ($i = 0; $i < $count+1; $i++) {
        $score_key = 'score' . $i;
        if (isset($_POST[$score_key])) {
            array_push( $scores, $_POST[$score_key]);
        }
    }

    return   $scores;
   }



///////////////////////////////////////////////////////////
static function maile($subject,$message){
    $email = $_POST['email'];
    
    
    
    
    require 'C:\wamp64\www\MVCGB-master-v4\vendor\autoload.php';
    
    
    
    

    $mail =new PHPMailer(true);
    
     //$mail->SMTPDebug = SMTP::DEBUG_SERVER;*
    
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    
    $mail->Username = "belghitialaouia@gmail.com";
    $mail->Password = "uksfwieevwxhditd";
    
    $mail->setFrom($email, "asmae");
    $mail->addAddress($email, "Dave");
    
    $mail->Subject = $subject;
    $mail->Body = $message;
    
    $mail->send();
    

    
    }

//////////////////////////////
static function str_random($length){
    $alphabet="0123456789azertyuiopqsdfghjklmwxcvbn";
   return substr(str_shuffle(str_repeat($alphabet,$length)),0,$length)  ;

}

//*********************************** */

function debug($variable){
    echo '<pre>'.print_r($variable,true).'</pre>';
}



static function logout(){
    //session_start();
   // $session = new Session();
    Session::getInstance();

    unset($_SESSION['auth']);

    //Session::getInstance()->setFlash('success',"vous etes maintenat deconnecter");

   $_SESSION['flash']['success']="vous etes maintenat deconnecter";

    functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');

   // header('Location: http://localhost/MVCGB-master-v4/?action=connexion');
    

}


static function errors(){
    $errors = [];


    $repository = new userRepository();

    if( $repository->findUserByMail() ){
      $errors['email']='+ cet email est dèja pris';
  }
  if(  $_POST['password']!=$_POST['password_confirm']){
    $errors['password']="+ vous n'avez pas enter le meme mot de passe";
  
  }
   return $errors;
  }
static function logged_only(){
    $user=new User();
    if(session_status() == PHP_SESSION_NONE ){
       Session::getInstance();
       return true;
    }
    if(!isset($_SESSION['auth'])){

        Session::getInstance()->setFlash('danger',"vous n'avez pas le droit d'y accéder , connectez vous");


        Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');
        exit();


    }
}
//*************************// */

function checkbox(string $name, string $value,array $data ): string
{   $attributes ='';
    $attributes .='checked';

    return <<<HTML
    <input type ="checkbox" name="{$name}[]" value="$value" $attributes
    >
HTML;

}

}


