<?php /*
namespace src\View;

class PaginatedQuery{
    private $query;
    private $queryCount;
    private $classMapping;
    private $pdo;
    private $perPage;

    public function __construct(
        string $query,
        string  $queryCount,
        string $classMapping,
        ?\lib\DB\Connexion $pdo =null,
        int $perPage=12
    ){

        $this->query=$query;
        $this->queryCount=$queryCount;
        $this->pdo = $pdo?: Connection::ge

    }



}*/