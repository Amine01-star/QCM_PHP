<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
</head>
<body>
    



 <?php $title = "page d'acceuil";?>
       <?php require_once 'src\View\Index\header.php';?>

        <div class="global"> 
        
          <section class="about" id="about">
            <div class="container">
              <div class="heading">
                <h5>EXPLORER</h5>
                <h2>Création et passage d'un QCM 
                </h2>
              </div>
        
              <div class="content flex  top">
                <div class="left">
                  <h3>Bienvenue sur notre site de création et de passage de QCM !
                  </h3>
                  <p>Notre plateforme a été conçue pour les utilisateurs qui cherchent à créer des questionnaires à choix multiples (QCM) de manière rapide et facile. Que vous soyez enseignant, formateur, ou simplement curieux, notre outil est adapté à tous les besoins..</p>
                  <p>Notre site est entièrement gratuit et accessible à tous. Il n'y a aucune limite au nombre de QCM que vous pouvez créer ou passer. De plus, notre plateforme est régulièrement mise à jour pour offrir une expérience utilisateur optimale.Alors n'hésitez plus et rejoignez la communauté de créateurs et de passeurs de QCM sur notre site !</p>
    
                </div>
                <div class="right">
                  <img src="src\View\image\image0.webp" alt="">
                </div>
              </div>
            </div>
          </section>
        
        
          <section class="wrapper">
            <div class="container">
              <div class="owl-carousel owl-theme">
                <div class="item">
                  <div class="heading">
                    <h5>Quiz</h5>
                    <h3>Créer un Qcm</h3>
                  </div>
                  <p>Un QCM (Questionnaire à Choix Multiples) est un type de test qui permet de poser des questions avec plusieurs options de réponse, dont une seule est correcte. Si vous souhaitez créer un QCM,</p>
                </div>

                <div class="item">
                  <div class="heading">
                    <h5>Quiz</h5>
                    <h3>Passer un QCM</h3>
                  </div>
                  <p>Un QCM, ou questionnaire à choix multiples, est un type de test où vous devez choisir la réponse la plus appropriée parmi une liste de choix proposés.</p>
                 
                </div>
              </div>
            </div>
          </section>
        
          <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>
          <script>
            $('.owl-carousel').owlCarousel({
              loop: true,
              margin: 10,
              nav: true,
              dots: false,
              navText: ["<i class='far fa-long-arrow-alt-left'></i>", "<i class='far fa-long-arrow-alt-right'></i>"],
              responsive: {
                0: {
                  items: 1
                },
                768: {
                  items: 1
                },
                1000: {
                  items: 1
                }
              }
            })
          </script>
        
        
        
        
        
        
        
        
        
          <section class="area top">
            <div class="container">
              <div class="heading">
                <h5>QCM</h5>
                <h3>Liste de QCM</h3>
              </div>
        
              <div class="content flex mtop">
                <div class="left">
                  <img src="src\View\image\image4.webp" alt="">
                </div>
                <div class="right">
                  <ul>
                    <li> Pertinence </li>
                    <li>Clarté </li>
                    <li>Variété</li>
                  </ul>
        
                  <p>Nos QCM ne sont pas seulement utiles pour évaluer les connaissances, mais peuvent également contribuer au développement de compétences clés telles que la réflexion critique et la résolution de problèmes.les QCM ne sont pas seulement utiles pour évaluer les connaissances, mais peuvent également contribuer au développement de compétences clés telles que la réflexion critique, la résolution de problèmes et la confiance en soi. </p>
        
 
                </div>
              </div>
            </div>
          </section>
        
          <section class="blog top" id="blog">
            <div class="container">
              <div class="heading">
                <h5>Notre Blog</h5>
                <h3>Pour s'améliorer</h3>
              </div>
        
              <div class="content grid mtop">
                <div class="box">
                  <div class="img">
                    <img src="src\View\image\image3.jpg" alt="">
                    <span></span>
                  </div>
                  <div class="text">
                    <div class="flex">
                      <i class="far fa-user"> <label>Admin</label> </i>
                      <i class="far fa-comments"> <label>Commentaire</label> </i>
                    </div>
                    <h3>Comment créer des QCM efficaces</h3>
                    <p> Créer un QCM (Questionnaire à Choix Multiples) efficace implique de comprendre les principes de base qui rendent un questionnaire à choix multiples pertinent et utile comme :</p>
                    <p> L'objectif,la larté,la variété,le niveau de difficulté,les réponses claires et la correction</p>

                  </div>
                </div>
                <div class="box">
                  <div class="img">
                    <img src="src\View\image\image2.jpg" alt="">
                    <span></span>
                  </div>
                  <div class="text">
                    <div class="flex">
                      <i class="far fa-user"> <label>Admin</label> </i>
                      <i class="far fa-comments"> <label>Comment</label> </i>
                    </div>
                    <h3>Les avantages des QCM pour l'apprentissage</h3>
                    <p>Favorisent la mémorisation : Les QCM peuvent aider à mémoriser plus facilement les concepts clés en leur fournissant des options de réponse spécifiques.</p>

<p>Évaluent la compréhension : Les QCM sont conçus pour évaluer la compréhension des concepts plutôt que la simple mémorisation.</p>
                  </div>
                </div>
                <div class="box">
                  <div class="img">
                    <img src="src\View\image\image1.jpg" alt="">
                    <span></span>
                  </div>
                  <div class="text">
                    <div class="flex">
                      <i class="far fa-user"> <label>Admin</label> </i>
                      <i class="far fa-comments"> <label>Comment</label> </i>
                    </div>
                    <h3>Les erreurs courantes à éviter lors de la création de QCM</h3>
                    <p> Questions ambiguës : Les questions doivent être claires et non ambiguës</p>
                    <p>Options de réponse incohérentes : Les options de réponse doivent être cohérentes et ne pas contenir d'informations contradictoires ou confuses</p>



                  </div>
                </div>
              </div>
            </div>
          </section>
        
          </div>

          <?php  require_once 'src\View\Index\footer.php';?>
</body>
</html>

    





