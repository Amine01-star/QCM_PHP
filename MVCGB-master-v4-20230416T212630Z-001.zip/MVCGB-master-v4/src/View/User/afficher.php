<?php
        require 'src\View\Index\header.php';

$html = '<table>';
foreach ($users as $user){


    $html.='<tr><td>'.$user->getId().'</td><td>'.$user->getNom().'</td><td>'.$user->getPassword().'</td><td>'.$user->getPrenom().'</td><td>'.$user->getEmail().'</td></tr>';
}
$html .='</table>';

echo $html;



 require 'src\View\Index\footer.php';
