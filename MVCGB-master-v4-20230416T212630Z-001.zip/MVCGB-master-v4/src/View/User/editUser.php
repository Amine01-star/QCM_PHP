
<?php

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBar.php';

require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php';


use src\Repository\userRepository;

?>

<?php 

if(isset($user)){
$nom=$user->getNom();
$prenom=$user->getPrenom();
$email=$user->getEmail();
$role=$user->getRoleId();

}
 ?>



<div class="d-flex justify-content-center">

  <h1 class="mb-4">Modifier un utilisateur</h1>

  <?php

if(isset($errorHtml)){      echo $errorHtml ;
}
    
  ?>
</div>
<!--<?php var_dump($_GET)?>-->


<section class="vh-100" style="background-color: #eee;">


  <div class="container h-100">

  
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-12 col-xl-11">
        <div class="card text-black" style="border-radius: 25px;">
          <div class="card-body p-md-5">
            <div class="row justify-content-center">
              <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">


                <form class="mx-1 mx-md-4" action ="" method="POST">



                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text"  name ="nom" id="form3Example1c" class="form-control" required value="<?php  if(isset($nom)){echo $nom;}  ?>" />
                      <label class="form-label" for="form3Example1c">Nom</label>
                    </div>
                  </div>

                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-user fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="text" name="prenom" id="form3Example1c" class="form-control" required  value="<?php    if(isset($prenom)){echo $prenom;} ?>" />
                      <label class="form-label" for="form3Example1c">Prenom</label>
                    </div>
                  </div>
                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">
                      <input type="email" name="email" id="form3Example3c" class="form-control" required value="<?php   if(isset($email)){echo $email;} ?> "/>
                      <label class="form-label" for="form3Example3c">Email</label>
                    </div>
                  </div>



                  <div class="d-flex flex-row align-items-center mb-4">
                    <i class="fas fa-key fa-lg me-3 fa-fw"></i>
                    <div class="form-outline flex-fill mb-0">





<input       <?php if($_SESSION['auth']->getRoleId()==2) {echo  'readonly="readonly"';} ?>  type="text" class="form-control rounded" placeholder="Search" aria-label="Search" required name="role_id" aria-describedby="search-addon" pattern="[1-2]" title="Please enter either 1 or 2"  value="<?php if(isset($role)){echo $role;}?>">


                      <label class="form-label" for="form3Example4cd">Role</label>
                    </div>
                  </div>



                  <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                    
                    
                    <button type="submit" class="btn btn-primary btn-lg" name="modifier">Modifier</button>
                  </div>





                </form>
                <form   method="POST">                  <div class="container h-100">
    <div class="input-group mb-3">
      <input type="text" class="form-control rounded" placeholder="Search" aria-label="Search"  name ="id" aria-describedby="search-addon">

      
      <button type="submit" class="btn btn-outline-primary" name ="recherche">search</button>
</div>
</div></form>

              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>





<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php';
?>
