
<?php
use src\View\functions;

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBar.php';

require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php';

?>




<?php  if (isset($_GET['delete'])):?>
<div class ="alert alert-success">
    Enregistrement supprimé avec succès

</div>
<?php endif?>

<div>

    

<div> <?php  $pageName=  Functions::pageName(); ?></div>




<div class="container mt-4" > <!-- Add a container and margin-top of 4 units -->
<div class="text-center pb-4"> <?php   echo $pageName;?></div>
<table class="mx-auto striped table-bordered" width="80%"    >
    <thead>
    <th class="text-center">Id</th>

    <th class="text-center">Nom</th>
    <th class="text-center">Prenom</th>
    <th class="text-center">email</th>
    <th class="text-center">Role</th>
    <th class="text-center">Comfirmation</th>





    <th class="text-center">Actions</th>

    </thead>
    <tbody>


    
        <?php foreach($users as $user):?>
            <tr>

            <td><?= $user->getId()?></td>

                 <td>
                 <?php $id= $user->getId() ?>
                    <a href="http://localhost/MVCGB-master-v4/?action=edit_users&id=<?php echo $id; ?>">
                    <?= $user->getNom()?> </a></td>
               
               
               
                <td><?= $user->getPrenom()?></td>
                <td><?= $user->getEmail()?></td>
                <td><?= $user->getRoleId()?></td>
                <td><?= $user->getConfirmedAt()?></td>

                


                <td>
                 <?php $id= $user->getId() ?>
                    <a href="http://localhost/MVCGB-master-v4/?action=edit_users&id=<?php echo $id; ?>" class ="btn btn-primary" >
                    Editer </a>
                    <a href="http://localhost/MVCGB-master-v4/?action=delete_User&id=<?php echo $id; ?>" class ="btn btn-danger" onclick="return confirm('voulez vous vraiment effectuer cette action?')">
                    Supprimer </a>
                    </td>

            </tr>
        <?php endforeach?>
    </tbody>
</table>
</div>



