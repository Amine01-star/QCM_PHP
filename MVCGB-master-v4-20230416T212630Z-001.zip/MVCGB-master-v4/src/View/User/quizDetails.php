<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';?>
	<title>Quiz Interface</title>
	<style>
		/* Add some styles to make the quiz look better */
		body {
			font-family: Arial, sans-serif;
			background-color: #f2f2f2;
		}
		h1, h2 {
			margin-left: 20px;
		}
		.quiz-container {
			max-width: 800px;
			margin: auto;
			padding: 20px;
			background-color: white;
			box-shadow: 0 0 10px rgba(0,0,0,0.2);
			border-radius: 5px;
		}
		.question {
			margin-top: 20px;
			font-weight: bold;
		}
		.options {
			margin-left: 20px;
			list-style-type: none;
		}
		.options li {
			margin-top: 10px;
		}
		.answer {
			font-style: italic;
			margin-left: 20px;
			
		}
		.score {
			text-align: center;
			font-weight: bold;
			margin-top: 20px;
			margin-bottom: 50px;
			font-size: 24px;
		}
	</style>
</head>
<body>
<div class="quiz-container">
	<?php 
	echo'<center>
	<h1>Titre du QCM: '.$quizs->getTitle().'</h1></center>
	<h2>Description:  '.$quizs->getDescription().'</h2>
	<h2>Durée: '.$quizs->getDuration().' minute</h2>
	<h2> Questions:</h2>

	<div class="question">
	';
	$q_num=1;
	foreach($questions as $question) {
		echo'
		<p> Question '.$q_num.': '.$question->getEnonce().'?</p>
		<ul class="options">
		';
		$anum=1;
		foreach($answers_by_question[$question->getId()] as $answer) {
			echo'
			<li>Reponse '.$anum.': '.$answer->getEnonce().'</li>';
			$anum++;
		}
		echo '</ul>'; // Close the <ul> tag before printing correct answers
		echo '<ul class="correct-answers">'; // Open a new <ul> tag for correct answers
		foreach($answers_correct[$question->getId()] as $correct) {
			echo'
			<li>Reponse correcte  : '.$correct->getEnonce().'</li>';
			$anum++;
		} 
		echo '</ul>'; // Close the <ul> tag for correct answers
		echo '
		<div class="score">Score: '.$question->getScore().'</div>
	</div>';
	$q_num++;
	}
	?>
</div>

	<?php 
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBar.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php';
?>
