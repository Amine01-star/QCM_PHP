
<?php
use src\View\functions;
use src\Entity\Quiz;

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';


require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php';

?>

<script>
$(document).ready(function() {
  $('input[name="inlineRadioOptions"]').on('change', function() {
    var value = $(this).val();
    var url = 'http://localhost/MVCGB-master-v4/?action=users_dash';
    if (value) {
      url += '&id=' + value;
    }
    window.location.href = url;
  });
});



</script>


<?php  if (isset($_GET['delete'])):?>
<div class ="alert alert-success">
    Enregistrement supprimé avec succès

</div>
<?php endif?>

<div>

    

<div> <?php  $pageName=  Functions::pageName(); ?></div>




<div class="container mt-4" > <!-- Add a container and margin-top of 4 units -->
<div class="text-center pb-4"> <?php   echo $pageName;?></div>
<table class="mx-auto striped table-bordered" width="100%"    >
    <thead>
    <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1">
  <label class="form-check-label" for="inlineRadio1">Tout</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
  <label class="form-check-label" for="inlineRadio2">validé</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" >
  <label class="form-check-label" for="inlineRadio3">non validé</label>
</div>



<script>
  // Get the last selected value from local storage
  const lastSelectedValue = localStorage.getItem('lastSelectedValue');
  
  // If there is a last selected value, check the corresponding radio button
  if (lastSelectedValue) {
    document.getElementById(lastSelectedValue).checked = true;
  }
  
  // Save the selected value to local storage when a radio button is clicked
  document.querySelectorAll('input[name="inlineRadioOptions"]').forEach((radioButton) => {
    radioButton.addEventListener('click', () => {
      localStorage.setItem('lastSelectedValue', radioButton.id);
    });
  });
</script>
    <th class="text-center">Id</th>

    <th class="text-center">Créateur</th>
    <th class="text-center">Titre</th>
    <th class="text-center">Description</th>
    <th class="text-center">Durée(min)</th>
    <th class="text-center">Date création</th>
    <th class="text-center">Date modification</th>
    <th class="text-center">status</th>
    <th class="text-center">validateur</th>






    <th class="text-center">Actions</th>

    </thead>
    <tbody>


    
        <?php foreach($quizs as $quiz):?>
            <tr>

            <td><?= $quiz->getId()?></td>

               
               
               
                <td><?= $quiz->getCreatorId()?></td>
                
                <td>
                  <form method="GET">
                  <input type="hidden" name="quiz_id" value=" <?php echo $quiz->getId() ?>"/></form>
                 <?php $id= $quiz->getId() ?>
                    <a href="http://localhost/MVCGB-master-v4/?action=edit_users&id=<?php echo $id; ?>">
                    <?= $quiz->getTitle()?> </a></td>
                <td><?= $quiz->getDescription()?></td>
                <td><?= $quiz->getDuration()?></td>
                <td><?= $quiz->getCreatedAt()?></td>
                <td><?= $quiz->getUpdatedAt()?></td>
                <td><?= $quiz->getStatus()?></td>
               <td><?= $quiz->getAdminName()?></td>



                

                


                <td  class="col-4 mx-auto text-center">
                 <?php $id= $quiz->getId() ?>
                    <a href="http://localhost/MVCGB-master-v4/?action=quizDetails&id=<?php echo $id; ?>" class ="btn btn-primary" >
                    Details </a>
                    <a href="http://localhost/MVCGB-master-v4/?action=validation&id=<?php echo $id; ?>" class ="btn btn-primary" >
                    Valider </a>
                    <a href="http://localhost/MVCGB-master-v4/?action=delete_Quiz&id=<?php echo $id; ?>" class ="btn btn-danger" onclick="return confirm('voulez vous vraiment effectuer cette action?')">
                    Supprimer </a>
                    </td>

            </tr>
        <?php endforeach?>
    </tbody>
</table>
</div>
<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBar.php';?>


