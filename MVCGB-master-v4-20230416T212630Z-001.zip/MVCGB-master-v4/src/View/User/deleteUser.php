
<?php

require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\header.php';
require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\sideBar.php';

require_once 'C:\wamp64\www\MVCGB-master-v4\src\Repository\userRepository.php';


use src\Repository\userRepository;

?>

<?php $id= $_GET['id'] ?>
<h1>Supprimer les users <?php var_dump($_GET)?></h1>





<?php require_once 'C:\wamp64\www\MVCGB-master-v4\src\View\Index\footer.php';
?>
