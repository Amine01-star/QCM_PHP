<?php
namespace src\Controller;
use src\Repository\quizRepository;
use  src\View\functions;
use lib\Controller\AbstractController;
use lib\View\View;
use src\Entity\quiz;



class  QuizController extends AbstractController {
  
  public  $error,$rep;  
  public function __construct() {
    $this->rep = new quizRepository();
  }

public function AfficherAllQuiz(){
    $quizs= $this->rep->findAll();

    $view = new View();
    $view->render('Quiz/afficherAllQuiz',['quiz'=>$quizs]);

}
// afficher tout les qcm que l'utilisateur à créer



function UserAfficherAllQuiz(){
  $etat=Functions::logged_only();

  $idCreator=$_SESSION['auth']->getId();      

  $quiz=$this->rep->getAll($idCreator);
  $view = new View();
  $view->render('Quiz/userQuiz',['quiz'=>$quiz]);

}
public function createQuiz(){





  $questions=Functions::countQuestions();
  $answers=Functions::countAnswers();
  $scores=Functions::countScore();
  $etat=Functions::logged_only();
  $reponse=Functions::countCorrectAnswers();

$tab=[];

  if(isset($_SESSION['auth'])){

  $idCreator=$_SESSION['auth']->getId();

  if(!empty($_POST)&& $etat ==true){
    $quiz = new Quiz($idCreator,$_POST["quiz_name"],$_POST["quiz_description"],$_POST['quiz_duration']);
    $idQuiz= $this->rep->create_quiz($quiz);
    for($i=0;$i<=count($questions);$i++){   
      if(isset($questions[$i])&&isset($scores[$i]) ){
       $id= $this->rep->addQuestion($idQuiz,$questions[$i],$scores[$i]);
       for ($j = 0; $j < count($answers[$i]); $j++) {
        $answer = $answers[$i][$j];
        array_push( $tab,$answer );



foreach ($tab as $element) {
  if (in_array($element, $reponse)) {
    $value = 1;
  }else{
    $value = 0;

  }
}


        $this->rep->addAnswer($answer, $id,$value);
      }      
      }
    }
    }


  }else{
    Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');

  }
  $view = new View();
  $view->render('Quiz/ajouterQuiz');
}

// supprimer un quiz
function DeleteQuiz(){
  if(isset($_GET['quiz_id'])){
      $repository=new quizRepository();
      $repository->delete_quiz($_GET['quiz_id']);
      $q=new QuizController();
      $q->UserAfficherAllQuiz();
  }
}
// afficher le quiz pour l'utilistaeur pour le passer
public function PasserQuiz() {
  Functions::logged_only();
  
  
    if(isset($_SESSION['auth'])){
    if (isset($_GET['quiz_id'])) {
      $quiz_id = $_GET['quiz_id'];     
      $questions = $this->rep->get_question($quiz_id);
      $quizs = $this->rep->getById($quiz_id);
      $answers = array(); // Create an empty array to store the answers for each question
      foreach($questions as $question) {
        $question_id = $question->getId();
        $question_answers = $this->rep->get_question_answers($question_id);
        $answers[$question_id] = $question_answers; // Append the answers for this question to the $answers array
      }
      $view =  new View();
      $view->render('Quiz/PasserQuiz', ['questions' => $questions, 'quizs' => $quizs, 'answers' => $answers]);
    }
  }else{
      Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');
  
    }
  }


// recuperer les reponses de l'utilisateur et calculer le score obtenu
public function Resultat(){ 
  Functions::logged_only();
  if(isset($_SESSION['auth'])) {
    $iduser = $_SESSION['auth']->getId();
    $quiz_id = $_POST['quiz_id'];
    $this->rep->deletereponse($iduser,$quiz_id);
    $questionnum = 0;
    while(isset($_POST['question_'.$questionnum])) {
      $question_id = $_POST['question_'.$questionnum];
      $answer_ids = [];
      $answernum = 1;
      foreach ($_POST as $key => $value) {
        if (strpos($key, 'answer'.$questionnum) === 0) {
          $answer_id = $value;
          $answer_ids[] = $answer_id;
          
        }
      } 
      if (!empty($answer_ids)) {
        $this->rep->save_user_quiz_responses($iduser, $quiz_id, $question_id, $answer_ids);
      }     
   //   var_dump($answer_ids);     
      $questionnum++;
    }
    $this->rep->is_correct();
    $score=$this->rep->score($iduser, $quiz_id);
    $view =  new View();
    $view->render('Quiz/Resultat', ['score'=>$score]);
    
    
  }
}




}
?>
