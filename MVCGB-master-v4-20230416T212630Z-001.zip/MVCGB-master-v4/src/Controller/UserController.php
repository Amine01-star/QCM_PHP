<?php
namespace src\Controller;
use  src\View\functions;
use lib\Controller\AbstractController;
use lib\View\View;
use src\Entity\user;
use src\Repository\quizRepository;
use src\Repository\userRepository;
use src\View\Session;

class  UserController extends AbstractController {
  
  public  $error,$rep,$rep1;  
  public function __construct() {
    $this->rep = new userRepository();
    $this->rep1 = new quizRepository();
  }

public function editUser() {
  $repository = new UserRepository();
  $errors=[];

  $etat=Functions::logged_only();
  if(isset($_SESSION['auth'])){

    $idCon=$_SESSION['auth']->getRoleId();

    if($etat ==true &&   $_SESSION['auth']->getRoleId()==3|| $_SESSION['auth']->getRoleId()==2){ 
  
  if (!empty($_GET['id'])) {
      $user = $repository->findUser($_GET['id']);

      if (isset($_POST['recherche'])&& isset($user)) {


            $user1 = $repository->findUser($_POST['id'],$idCon);






          if (isset($user1)) {
              $id =  $_POST['id'] ;
              Functions::redirect("http://localhost/MVCGB-master-v4/?action=edit_users&id=$id");
          }else{
            
        $errors['id']= "+ veuiller saisir un id valide";

        $errorHtml = '<div class="alert alert-danger">';
        foreach ($errors as $error) {
            $errorHtml .= '<li>' . $error . '</li>';
        }
        $errorHtml .= '</div>';
        $view = new View();

        $view->render('User/editUser', ['errorHtml' => $errorHtml]);

          }
      }
      if (isset($_POST['modifier'])) {
          // update user with new data
          $updatedUser = $repository->updateUser($_GET['id']);
          // redirect to edited user page
          Functions::redirect("http://localhost/MVCGB-master-v4/?action=edit_users&id=".$_GET['id']);
      }
  } elseif (isset($_POST['recherche'])) {


      $user = $repository->findUser($_POST['id'],$idCon);



      if (isset($user)) {
          $id = $_POST['id'];
          Functions::redirect("http://localhost/MVCGB-master-v4/?action=edit_users&id=$id");
      }else{
            
        $errors['id']= "+ veuiller saisir un id valide";

        $errorHtml = '<div class="alert alert-danger">';
        foreach ($errors as $error) {
            $errorHtml .= '<li>' . $error . '</li>';
        }
        $errorHtml .= '</div>';
        $view = new View();

        $view->render('User/editUser', ['errorHtml' => $errorHtml]);

          }
  }
if(isset($user)){
$view = new View();
$view->render('User/editUser', ['user' => $user]);
}else{
$view = new View();
$view->render('User/editUser');
}

}
}

Functions::redirect('http://localhost/MVCGB-master-v4/?action=/');


}


  public function Afficher() {
    $users =  $this->rep->findAll(3,1);
    $view = new View();
    $view->render('User/afficher',['users' => $users]);
  }

  public function UserQuest() {
    $view = new View();
    $view->render('User/questionaire');
  }

  public function Aboutme() {
    $etat = Functions::logged_Only();
    if(isset($_SESSION['auth'])){
      if ($etat && $_SESSION['auth']->getRoleId() == 3||$_SESSION['auth']->getRoleId() == 2) {
        $id=$_SESSION['auth']->getId();
        $user =  $this->rep->findUser($id);
         if(!empty($_POST) && isset($_POST['modifier'])){      
           $user=   $this->rep->updateSuper();
          }

        $view = new View();
        $view->render('Index/aboutme', ['user' => $user]);
      }elseif($_SESSION['auth']->getRoleId() == 1)
      //Session::getInstance()->setFlash('success',"Veuillez saisir un id");
{      Functions::redirect('src\View\Index\introuvable.php');
}
    }else{
      Functions::redirect('http://localhost/MVCGB-master-v4/?action=/');
    }     
  }

  public function ForgetPass() {
    if(!empty($_POST) && !empty($_POST['email'])){
      $users= $this->rep-> tokenReset();
        if(isset($users[0])){
          $reset_token =  Functions::str_random(60);
          Functions::maile('Renitiatilisation de votre mot de passe', "Afin de réinitialiser votre mot de passe merci de cliquer sur ce lien\n\nhttp://localhost/MVCGB-master-v4/?action=resetPass&id={$users[0]->getId()}&token=$reset_token");
           $this->rep-> updateReset($reset_token, $users);
          Session::getInstance()->setFlash('success',"Les instructions du rappel de mot de passe vous ont été envoyées par emails");
          Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');
          exit();
        }else{
            Session::getInstance()->setFlash('danger','Aucun compte ne correspond à cet adresse');
            }
  }     
  $view = new View();
  $view->render('Index/forget');
  }

  public function Connexion() {
    Session::getInstance();
    $user= $this->rep->connexion();
    if (!empty($user)) {
      if(password_verify(htmlspecialchars($_POST['password']),$user[0]->getPassword())){
        Session::write('auth',$user[0]);
        Session::getInstance()->setFlash('success',"vous etes maintenant connécté");
        if( $user[0]->getRoleId()==3){
          Functions::redirect('http://localhost/MVCGB-master-v4/?action=dashboard');
        }elseif($user[0]->getRoleId()==2){
          Functions::redirect('http://localhost/MVCGB-master-v4/?action=users');
        }else{
          Functions::redirect('http://localhost/MVCGB-master-v4/?action=create_quiz');
        }
        exit();
  
      }else{
        Session::getInstance()->setFlash('danger',"email ou mot de passe incorrect");
      } 
    }elseif(isset($_POST['submitlogin'])) {
      Session::getInstance()->setFlash('danger',"Inscription non accomplie");
    }
    $view = new View();
    $view->render('Index/login');
   }
    


   

  public function ResetPass() {
    $errors = [];
    if(isset($_GET['id']) && isset($_GET['token'])){
        $users= $this->rep->ResetPassword();

          if(isset($users[0])){
              if(!empty($_POST)){
                  if(!empty($_POST['password']) && htmlspecialchars( $_POST['password']) ==  htmlspecialchars($_POST['password_confirm'])){
                      $password = password_hash(htmlspecialchars($_POST['password']), PASSWORD_BCRYPT);
                       $this->rep->updtePassword($password);
                      Session::getInstance()->setFlash('success','Votre mot de passe a bien été modifié');
                      Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');
                      exit();
                  }else{
                    $errors['password']= "+ veuiller saisinr le meme mot de passe";
                  }
              }
          }else{
            Session::getInstance()->setFlash('danger',"Ce token n'est pas valide");
            Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');
            exit();
          }
    }else{
      Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');
      exit();
      }
    $view = new View(); 
    if (!empty($errors)) {
      $errorHtml = '<div class="alert alert-danger">';
      foreach ($errors as $error) {
          $errorHtml .= '<li>' . $error . '</li>';
      }
      $errorHtml .= '</div>';
      $view->render('Index/resetPass', ['errorHtml' => $errorHtml]);
    } else {
      $view->render('Index/resetPass');
    }
  }


  public function Create() { 
    $view = new View();
    $token =  Functions::str_random(60);
    if(!empty($_POST)){


    $errors=Functions::errors();  
    if(empty($errors)){
      $password = password_hash(htmlspecialchars($_POST['password']), PASSWORD_BCRYPT);
      $user_id=  $this->rep->create($password,$token,1);
      Session::getInstance()->setFlash('success',"un email de comfirmation voua été envoyé");
      Functions::maile("Comfirmation email"," merci de cliquer sur ce lien pour valider votre compte\n\nhttp://localhost/MVCGB-master-v4/?action=comfirm_users&id=$user_id&token=$token");
      $view->render('Index/register');

    }else{
      $errorHtml = '<div class="alert alert-danger">';
      foreach ($errors as $error) {
          $errorHtml .= '<li>' . $error . '</li>';
      }
      $errorHtml .= '</div>'; 
      $view->render('Index/register', ['errorHtml' => $errorHtml]);
    } 
    }else{
      $view->render('Index/register');

    }

  }

  public function QuizDetails(){
    $questions = $this->rep1->get_question($_GET['id']);
    $quizs = $this->rep1->getById($_GET['id']);
    $answers_by_question = array(); // tableau pour stocker les réponses pour chaque question
    $answers_correct= array(); // tableau pour stocker les réponses pour chaque question

    foreach($questions as $question){
        $answers_by_question[$question->getId()] = $this->rep1->get_question_answers($question->getId());
        $answers_correct[$question->getId()] = $this->rep1->get_correct($question->getId());

    }


    $view = new View();
    $view->render('User/quizDetails',['questions'=>$questions, 'quizs'=>$quizs,'answers_by_question'=>$answers_by_question,'answers_correct'=>$answers_correct]);
}



  
  public function ValiderQuiz(){
    Functions::logged_only();
    $user =  $this->rep->findQuiz($_GET['id'] );
    $idAdmin=$_SESSION['auth']->getId();
    $this->rep->validateQuiz($idAdmin,$_GET['id']);

      Functions::redirect('http://localhost/MVCGB-master-v4/?action=users_dash');
    $view = new View();
    $view->render('User/deleteQuiz');

  }

  public function DeleteUser(){
    Functions::logged_only();
    $user =  $this->rep->findUser($_GET['id'] );

    $this->rep->delete($_GET['id']);

    //var_dump($user->getRoleId());

  if($_SESSION['auth']->getRoleId()==3){
    if($user->getRoleId()==1){
           Functions::redirect('http://localhost/MVCGB-master-v4/?action=users');

    }elseif($user->getRoleId()==2){
            Functions::redirect('http://localhost/MVCGB-master-v4/?action=dashboard');

    }
     


    }elseif($_SESSION['auth']->getRoleId()==2){
    Functions::redirect('http://localhost/MVCGB-master-v4/?action=users');

  }else{
    Functions::redirect('http://localhost/MVCGB-master-v4/?action=/');

  }
    
    $view = new View();
    $view->render('User/deleteUser');
  }


  public function DeleteQuiz(){

    Functions::logged_only();
    $user =  $this->rep->findQuiz($_GET['id'] );
    $this->rep->deleteQuiz($_GET['id']);

      Functions::redirect('http://localhost/MVCGB-master-v4/?action=users_dash');


  
    
    $view = new View();
    $view->render('User/deleteQuiz');
  }



  public function CreateAdmin(){
    $etat=Functions::logged_only();
    if(isset($_SESSION['auth'])){
      if($etat ==true &&   $_SESSION['auth']->getRoleId()==3){
          $errors = [];
          $token =  Functions::str_random(60);

          if (htmlspecialchars(isset($_POST['password']))) {
            $password = password_hash(htmlspecialchars($_POST['password']), PASSWORD_BCRYPT);
          }
          if(!empty($_POST)){
            if( htmlspecialchars($_POST['password'])!=htmlspecialchars($_POST['password_confirm'])){
              $errors['password']="+ vous n'avez pas enter le meme mot de passe";
            }
            if( !empty(htmlspecialchars($_POST['email']))){
              $user= $this->rep->findUserByMail();
              if( $user){
                $errors['email']='+ cet email est dèja pris';
              }
            }
            if(empty($errors)){
              $user_id=  $this->rep->create($password,$token,2);
              Session::getInstance()->setFlash('success',"un email de comfirmation voua été envoyé");
              Functions::maile("Comfirmation email"," merci de cliquer sur ce lien pour valider votre compte\n\nhttp://localhost/MVCGB-master-v4/?action=comfirm_users&id=$user_id&token=$token");

            }
          }
          $view = new View();
          if (!empty($errors)) {
            $errorHtml = '<div class="alert alert-danger">';
            foreach ($errors as $error) {
                $errorHtml .= '<li>' . $error . '</li>';
            }
              $errorHtml .= '</div>';
            
              $view->render('User/createAdmin', ['errorHtml' => $errorHtml]);
          } else {
      $view->render('User/createAdmin');

      }
      }else{

        Functions::redirect('src\View\Index\introuvable.php');
     // echo"vous n'avez pas le droit d'accéder à cette page";
      }
    } else{
      Functions::redirect('http://localhost/MVCGB-master-v4/?action=/');
    } 
  }


  public function Dashboard() {
    $etat=Functions::logged_only();
    if(isset($_SESSION['auth'])){
      if($etat ==true &&   $_SESSION['auth']->getRoleId()==3){  
        $users =  $this->rep->findAll(3,2);
        $view = new View();
        $view->render('User/adminDash',['users' => $users]);
        }else{
          Functions::redirect('src\View\Index\introuvable.php');
          //echo"vous n'avez pas le droit d'accéder à cette page";
        }
    }
    else{
      Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');
    }   
  }

  public function Dashboard1() {
    $etat=Functions::logged_only();
    if(isset($_SESSION['auth'])){
      if($etat ==true &&   $_SESSION['auth']->getRoleId()==3|| $_SESSION['auth']->getRoleId()==2){ 
        $users =  $this->rep->findAll(2,1);
 

        $view = new View();
        $view->render('User/adminDash',['users' => $users]);
        }else{
         // echo"vous n'avez pas le droit d'accéder à cette page";
         Functions::redirect('src\View\Index\introuvable.php');
        }
    }
    else{
      Functions::redirect('http://localhost/MVCGB-master-v4/?action=/');
    }

  }


  public function Dashboard2() {
    $etat=Functions::logged_only();
    if(isset($_SESSION['auth'])){
      if($etat ==true &&   $_SESSION['auth']->getRoleId()==3|| $_SESSION['auth']->getRoleId()==2){ 
if(isset($_GET['id'])){

    if($_GET['id']== "option1"){
      $quizs =  $this->rep->findAllQuizs(1);

    }elseif($_GET['id']== "option2"){
      $quizs =  $this->rep->findAllQuizs(3);

    }elseif($_GET['id']== "option3"){
      $quizs =  $this->rep->findAllQuizs(2);

    }


}else{
  $quizs =  $this->rep->findAllQuizs(1);}

 

        $view = new View();
        $view->render('User/quizDash',['quizs' => $quizs]);
        }else{
         // echo"vous n'avez pas le droit d'accéder à cette page";
         Functions::redirect('src\View\Index\introuvable.php');
        }
    }
    else{
      Functions::redirect('http://localhost/MVCGB-master-v4/?action=/');
    }

  }






  public function EditSuperPass() {
    $etat=Functions::logged_only();
    if(isset($_SESSION['auth'])){
      if($etat ==true &&   $_SESSION['auth']->getRoleId()==3||$_SESSION['auth']->getRoleId()==2){
        if(!empty($_POST)){

                $hashed_password = $_SESSION['auth']->getPassword();

                $entered_password = $_POST['password'];
                $new_password = $_POST['password_confirm'];


                if (!password_verify($entered_password, $hashed_password)) {

            Session::getInstance()->setFlash('danger',"Les mots de passes ne correspondent pas");  
          }else{
            $user_id = $_SESSION['auth']->getId();
            $password= password_hash( $new_password  , PASSWORD_BCRYPT);
            $this->rep->editPass($password,$user_id);
            Session::getInstance()->setFlash('success',"Votre mot de passe a bien été mis à jour");
          }
        }
        $view = new View();
        $view->render('User/super');
      }else{
        echo"le droit d'accéder à cette page";
      }
    }else{
      Functions::redirect('http://localhost/MVCGB-master-v4/?action=/');
    }
  }

  public function EditPass() {
    Functions::logged_only();
    if(!empty($_POST)){
      if(empty(htmlspecialchars($_POST['password'])) || htmlspecialchars($_POST['password']) != htmlspecialchars($_POST['password_confirm'])){
        Session::getInstance()->setFlash('danger',"Les mots de passes ne correspondent pas");   
      }else{
        $user_id = $_SESSION['auth']->getId();
        $password= password_hash(htmlspecialchars($_POST['password']), PASSWORD_BCRYPT);
        $this->rep->editPass($password,$user_id); 
        Session::getInstance()->setFlash('success',"Votre mot de passe a bien été mis à jour");
      }
    }
    $view = new View();
    $view->render('User/account');
  }



  public function Comfirm(){  
      $user_id = $_GET['id'];
      $token = $_GET['token'];
      $user=  $this->rep->comfirmation($user_id);
      if($user[0] && $user[0]->getConfirmationToken() ==$token){
        $this->rep->updateComfirmation($user_id);
        Session::write('auth',$user[0]);
        if($user[0]->getRoleId()==2){
          Functions::redirect('http://localhost/MVCGB-master-v4/?action=users');
        }elseif(($user[0]->getRoleId()==3)){  
              Functions::redirect('http://localhost/MVCGB-master-v4/?action=dashboard');
        }elseif($user[0]->getRoleId()==1){
          Functions::redirect('http://localhost/MVCGB-master-v4/?action=create_quiz');
        }
        Session::getInstance()->setFlash('success','votre compte est validé');
        Session::write('auth',$user[0]);
      }else{
        Session::getInstance()->setFlash('danger',"ce token n'est plus valide");
        Functions::redirect('http://localhost/MVCGB-master-v4/?action=connexion');
      }    
    $view = new View();
    $view->render('User/comfirm');

  }


}





  