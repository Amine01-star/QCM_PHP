<?php
namespace src\Entity;

class Question {

  protected $id;
  protected $quiz_id;
  protected $enonce;
  protected $score;
  protected $answers = [];

  public function __construct(){
    if(func_num_args()==3){
      $this->enonce=func_get_arg(0);
      $this->score=func_get_arg(1);
    }
   
  }

  public function getId() {
    return $this->id;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function getQuizId() {
    return $this->quiz_id;
  }

  public function setQuizId($quiz_id) {
    $this->quiz_id = $quiz_id;
  }

  public function getEnonce() {
    return $this->enonce;
  }

  public function setEnonce($enonce) {
    $this->enonce = $enonce;
  }

  public function getScore() {
    return $this->score;
  }

  public function setScore($score) {
    $this->score = $score;
  }

  public function getAnswers() {
    return $this->answers;
  }

  public function setAnswers($answers) {
    $this->answers = $answers;
  }



}