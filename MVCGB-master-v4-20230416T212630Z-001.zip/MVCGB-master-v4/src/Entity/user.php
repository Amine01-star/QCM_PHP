<?php

namespace src\Entity;

class user {

    protected $id;
    protected $nom;
    protected $prenom;
    protected $email;
    protected $password;
 protected  $confirmation_token;	
   protected  $confirmed_at	;
   protected $reset_token;

   protected $reset_at	;


   protected  $role_id;



   


    public function __construct()
    {
        if(func_num_args()==3){
            $this->nom = func_get_arg(0);
            $this->prenom = func_get_arg(1);
            $this->email = func_get_arg(2);
        }
        if(func_num_args()==4){
            $this->id = func_get_arg(0);
            $this->nom = func_get_arg(1);
            $this->prenom = func_get_arg(2);
            $this->email = func_get_arg(3);
        }
         
    }

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }
 /**
     * Get the value of id
     */ 
    public function setRoleId($role_id)
    {
        $this->role_id=$role_id;
        return $this;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function getRoleId()
    {


        
           return $this->role_id;
        

    }

    /**
     * Get the value of nom
     */ 
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set the value of nom
     *
     * @return  self
     */ 
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get the value of prenom
     */ 
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Set the value of prenom
     *
     * @return  self
     */ 
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * Get the value of email
     */ 
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     *
     * @return  self
     */ 
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }



    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set the value of email
     *
     * @return  self
     */ 
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }


     /**
     * Get the value of confirmation_token
     */
    public function getConfirmationToken() {
        return $this->confirmation_token;
      }
    
      public function setConfirmationToken($confirmation_token) {
        $this->confirmation_token = $confirmation_token;
      }

    /**
     * Get the value of confirmed_at
     */
    public function getConfirmedAt()
    {
        return $this->confirmed_at;
    }

    /**
     * Set the value of confirmed_at
     */
    public function setConfirmedAt($confirmed_at): self
    {
        $this->confirmed_at = $confirmed_at;

        return $this;
    }

       /**
     * Get the value of reset_token
     */
    public function getResetToken()
    {
        return $this->reset_token;
    }

    /**
     * Set the value of reset_token
     */
    public function setResetToken($reset_token): self
    {
        $this->reset_token = $reset_token;

        return $this;
    }

  /**
     * Get the value of reset_at
     */
    public function getResetAt()
    {
        return $this->reset_at;
    }

    /**
     * Set the value of reset_at
     */


     /**
     * Set the value of reset_at
     */



     public function setResetAt($reset_at): self
     {
 
        $this->reset_at = $reset_at;

         return $this;
     }
 

}