<?php
namespace src\Entity;
class Quiz {
    protected $id;
    protected $title;
    protected $description;
    protected $duration;	
    protected $created_at;	
    protected $updated_at;
    protected $questions;
    protected $Creator_id;
    protected $status;
    protected $id_admin;

    protected $admin_name; 


    public function __construct() {
        if(func_num_args()==7){
            $this->id=func_get_arg(0);
            $this->Creator_id=func_get_arg(0);
            $this->title=func_get_arg(2);
            $this->description=func_get_arg(3);
            $this->duration=func_get_arg(4);
            $this->created_at=func_get_arg(5);
            $this->updated_at=func_get_arg(6);
            $this->status=func_get_arg(1);
            $this->id_admin=func_get_arg(1);
            
        }
        if(func_num_args()==3){
            $this->title = func_get_arg(0);
            $this->description= func_get_arg(1);
            $this->duration = func_get_arg(2);
        }
        if(func_num_args()==4){
            $this->Creator_id= func_get_arg(0);
            $this->title = func_get_arg(1);
            $this->description= func_get_arg(2);
            $this->duration = func_get_arg(3);
            
        }
        if(func_num_args()==5){
            $this->id= func_get_arg(0);
            $this->Creator_id= func_get_arg(1);
            $this->title = func_get_arg(2);
            $this->description= func_get_arg(3);
            $this->duration = func_get_arg(4);
            
        }
        $this->questions = array();
    }
    
    


    /**
     * Get the value of id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of title
     */
    
     public function getAdminName()
     {
         return $this->admin_name;
     }
     
     public function setAdminName($admin_name)
     {
         $this->admin_name = $admin_name;
     }

    public function getTitle() {
        return $this->title;
    }
    
    public function setTitle($title) {
        $this->title = $title;
    }
    
    public function getDescription() {
        return $this->description;
    }
    
    public function setDescription($description) {
        $this->description = $description;
    }
    
    public function getDuration() {
        return $this->duration;
    }
    
    public function setDuration($duration) {
        $this->duration = $duration;
    }
    
    public function getCreatedAt() {
        return $this->created_at;
    }
    
    public function setCreatedAt($created_at) {
        $this->created_at = $created_at;
    }
    
    public function getUpdatedAt() {
        return $this->updated_at;
    }
    
    public function setUpdatedAt($updated_at) {
        $this->updated_at = $updated_at;
    }
    
    public function getQuestions() {
        return $this->questions;
    }
    
    public function setQuestions($questions) {
        $this->questions = $questions;
    }
    
    public function getCreatorId() {
        return $this->Creator_id;
    }
    
    public function setCreatorId($Creator_id) {
        $this->Creator_id = $Creator_id;
    }
    
    public function getStatus() {
        return $this->status;
    }
    
    public function setStatus($status) {
        $this->status = $status;
    }
    
    public function getIdAdmin() {
        return $this->id_admin;
    }
    
    public function setIdAdmin($id_admin) {
        $this->id_admin = $id_admin;
    }
}

?>
