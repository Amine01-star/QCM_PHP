<?php
namespace src\Entity;

class Reponse {

    protected $id;
    protected $id_quest;
    protected $enonce  ;
    protected $is_correct;



        
    public function getEnonce() {
        return $this->enonce;
    }

    public function setEnonce($newEnonce) {
        $this->enonce = $newEnonce;
    }
    
    public function getIdQuest() {
        return $this->id_quest;
    }
    
    public function setIdQuest($id_quest) {
        $this->id_quest = $id_quest;
    }


    // Getter
    public function getId() {
        return $this->id;
    }

    // Setter
    public function setId($id) {
        $this->id = $id;
    }

    /**
     * Get the value of is_correct
     */
    public function getIsCorrect()
    {
        return $this->is_correct;
    }

    /**
     * Set the value of is_correct
     */
    public function setIsCorrect($is_correct): self
    {
        $this->is_correct = $is_correct;

        return $this;
    }
}